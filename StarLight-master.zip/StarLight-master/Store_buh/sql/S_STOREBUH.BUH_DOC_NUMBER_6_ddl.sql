-- Start of DDL Script for Sequence S_STOREBUH.BUH_DOC_NUMBER_5
-- Generated 17.04.2010 15:06:22 from S_STOREBUH@STARDB

CREATE SEQUENCE s_storebuh.buh_doc_number_6
  INCREMENT BY 1
  START WITH 1
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  NOCYCLE
  NOORDER
  CACHE 20
/

create public synonym buh_doc_number_6 for s_storebuh.buh_doc_number_6
-- End of DDL Script for Sequence S_STOREBUH.BUH_DOC_NUMBER_5

