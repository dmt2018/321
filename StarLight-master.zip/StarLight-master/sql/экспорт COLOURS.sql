SELECT a.col_id, a.colour, a.ord
  FROM colours a
