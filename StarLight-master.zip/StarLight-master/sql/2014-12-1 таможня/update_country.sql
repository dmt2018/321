update countries set country_eng = 'Netherlands' where c_id = 1;
update customs_inv_data_as_is set hol_country = 'Netherlands' where hol_country = 'NL';

