SELECT a.ft_id, a.f_type, a.ft_mask, a.ht_id, a.id_departments
  FROM flower_types a
