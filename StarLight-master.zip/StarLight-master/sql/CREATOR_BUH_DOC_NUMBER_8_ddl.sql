-- Start of DDL Script for Sequence CREATOR.BUH_DOC_NUMBER_3
-- Generated 9.02.2014 23:24:17 from CREATOR@STAR_NEW



CREATE SEQUENCE buh_doc_number_8
  INCREMENT BY 1
  START WITH 1
  MINVALUE 0
  MAXVALUE 9999999999999999999999999999
  NOCYCLE
  NOORDER
  NOCACHE
/

insert into buh_doc_type values(8,'���');
/

-- End of DDL Script for Sequence CREATOR.BUH_DOC_NUMBER_3

