SELECT a.fst_id, a.f_sub_type, a.ft_id, a.hol_sub_type, a.mnemo,
       a.sub_weight
  FROM flower_subtypes a
