SELECT a.h_col_id, a.col_id, a.hol_colour
  FROM h_colours a
