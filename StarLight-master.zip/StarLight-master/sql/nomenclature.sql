INSERT INTO hol_subtype_def_pack 
VALUES(1,1,'new_hol_subtype');
INSERT INTO hol_subtype_def_pack 
VALUES(1,1,'new_hol_subtype');
INSERT INTO hol_subtype_def_pack 
VALUES(10,1,'Rosa kleinbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(20,2,'Rosa grootbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(20,2,'Rosa Ecuador');
INSERT INTO hol_subtype_def_pack 
VALUES(5,3,'Dendranthema tros kas');
INSERT INTO hol_subtype_def_pack 
VALUES(10,3,'Dendrant. geplozen buiten');
INSERT INTO hol_subtype_def_pack 
VALUES(5,3,'Dendranthema tros buiten');
INSERT INTO hol_subtype_def_pack 
VALUES(10,4,'Dianthus barbatus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,4,'Dianthus barbatus p. bos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,4,'Dianthus overig');
INSERT INTO hol_subtype_def_pack 
VALUES(20,4,'Dianthus standaard');
INSERT INTO hol_subtype_def_pack 
VALUES(10,4,'Dianthus tros');
INSERT INTO hol_subtype_def_pack 
VALUES(10,5,'Lilium Aziatische Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,5,'Lilium Longifl. x Aziat.');
INSERT INTO hol_subtype_def_pack 
VALUES(10,5,'Lilium longiflorum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,5,'Lilium Oriental Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,5,'Lilium overig');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Echinops');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Eremurus');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Eryngium');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Euonymus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Eupatorium');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Euphorbia fulgens');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Euphorbia fulgens vertakt');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Euphorbia overig');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Eustoma russell. enkel');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Eustoma russell. gevuld');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Freesia dubbel');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Freesia enkel');
INSERT INTO hol_subtype_def_pack 
VALUES(30,6,'Fritillaria');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Gentiana');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Gladiolus grootbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Gomphrena globosa');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Gypsophila overig');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Gypsophila paniculata');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Helenium');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Heliconia');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Helleborus');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Hyacinthus orientalis');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Hyacinthus orientalis bos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Hypericum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Ilex');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Iris');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Iris (vaste plant)');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Ixia');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Kerstartikelen per kilo');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Kniphofia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Lathyrus');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Leucadendron');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Leucospermum cordifolium');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Liatris');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Ligustrum');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Limonium overig');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Limonium sinensis');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Limonium sinuatum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Matthiola incana');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Monarda');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Muscari');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Narcissus met blad');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Narcissus zonder blad');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Nerine Bowdenii Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Nigella');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Nigella p. bos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Origanum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Ornithogalum');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Overig bolbloemen p. stuk');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Overig decoratieartikelen');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Overig decoratiegroen st.');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Overig per stuk');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Overig per bos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Overig trekheesters');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Phlox Paniculata Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Physostegia virginiana');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Protea');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Prunus');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Ranunculus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Siervruchten');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Skimmia per bos');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Skimmia');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Solidago');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Symphoricarpos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Syringa');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Tagetes');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Tanacetum overig');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Tanacetum parthenium');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Trachelium caeruleum');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Triteleia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Veronica');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Viburnum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Viburnum per bos');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Zantedeschia aethiopica');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Zantedeschia overig');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Zinnia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Alstroemeria');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Anemone overig');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Anemone coronaria');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Anigozanthos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Antirrhinum majus');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Aster Universum Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Bouvardia enkelbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Bouvardia dubbelbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Brassica oleracea');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Chamelaucium');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Acacia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Astrantia major');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Godetia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Agapanthus');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Calendula');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Ageratum');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Delphinium Belladonna Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Amaranthus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Clematis');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Asclepias');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Spiraea');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Delphinium elatum Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Leucanthemum vulgare');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Carthamus tinctorius');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Alchemilla');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Banksia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Ammi');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Delphinium ajacis');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Leucospermum overig');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Ozothamnus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Paeonia');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Allium');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Leucanthemum Maximum Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Nerine overig');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Campanula');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Nerine Companion Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Scilla');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Prunus per bos');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Celosia Cristata Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Celosia overig');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Hydrangea');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Curcuma');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Gladiolus kleinbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Crocosmia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Aquilegia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Dahlia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Aconitum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Lysimachia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Saponaria per bos');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Achillea');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Cirsium');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Astilbe');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Celosia Plumosa Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Saponaria');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Scabiosa');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Rubus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Centaurea');
INSERT INTO hol_subtype_def_pack 
VALUES(25,6,'Callistephus chinensis');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Rudbeckia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Mentha');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Alcea rosea');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Sedum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Chenopodium');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Artemisia');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Rosa (Rozenbottel)');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Nerine Sarniensis Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Leycesteria');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Siervruchten per bak');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Echeveria');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Delphinium consolida');
INSERT INTO hol_subtype_def_pack 
VALUES(10,6,'Campanula per bos');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Chamaecyparis');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Pieris');
INSERT INTO hol_subtype_def_pack 
VALUES(50,6,'Tulipa met bol');
INSERT INTO hol_subtype_def_pack 
VALUES(1,6,'Lavatera');
INSERT INTO hol_subtype_def_pack 
VALUES(5,6,'Zantedeschia aethiop');
INSERT INTO hol_subtype_def_pack 
VALUES(20,7,'Gerbera grootbloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(0,7,'Gerbera mini');
INSERT INTO hol_subtype_def_pack 
VALUES(60,7,'Gerbera micro');
INSERT INTO hol_subtype_def_pack 
VALUES(50,8,'Tulipa dubbel');
INSERT INTO hol_subtype_def_pack 
VALUES(0,8,'Tulipa enkel');
INSERT INTO hol_subtype_def_pack 
VALUES(50,8,'Tulipa gefranjerd');
INSERT INTO hol_subtype_def_pack 
VALUES(50,8,'Tulipa leliebloemig');
INSERT INTO hol_subtype_def_pack 
VALUES(50,8,'Tulipa parkiet');
INSERT INTO hol_subtype_def_pack 
VALUES(50,8,'Tulipa geplukt met blad');
INSERT INTO hol_subtype_def_pack 
VALUES(5,9,'Gloriosa');
INSERT INTO hol_subtype_def_pack 
VALUES(16,9,'Orchideeen ov. p. bloem');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Orchideeen ov. p. tak');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Tillandsia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,9,'Paphiopedilum');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Cymbidium mini p. tak');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Cymbidium grootbl. p. tak');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Anthurium Andreanum Grp');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Anthurium overig');
INSERT INTO hol_subtype_def_pack 
VALUES(25,9,'Phalaenopsis');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Cymbidium verpakt');
INSERT INTO hol_subtype_def_pack 
VALUES(10,9,'Overig decoratiegroen st');
INSERT INTO hol_subtype_def_pack 
VALUES(10,9,'Dendrobium');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Cymbidium grootbl. p. ta');
INSERT INTO hol_subtype_def_pack 
VALUES(1,9,'Cymbidium per bloem');
INSERT INTO hol_subtype_def_pack 
VALUES(1,10,'Overig decoratiegroen bos');
INSERT INTO hol_subtype_def_pack 
VALUES(1,10,'Hedera');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Hosta');
INSERT INTO hol_subtype_def_pack 
VALUES(1,10,'Myrtus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Photinia');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Weigela');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Setaria');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Pennisetum');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Miscanthus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Cotinus');
INSERT INTO hol_subtype_def_pack 
VALUES(10,10,'Quercus');
INSERT INTO hol_subtype_def_pack 
VALUES(1,10,'Cutleaves');
INSERT INTO hol_subtype_def_pack 
VALUES(1,10,'Other cutflowers');
INSERT INTO hol_subtype_def_pack 
VALUES(10,12,'Rosa tros');
INSERT INTO hol_subtype_def_pack 
VALUES(1,13,'Hippeastrum per steel');
INSERT INTO hol_subtype_def_pack 
VALUES(25,14,'Dendranthema tros santini');
INSERT INTO hol_subtype_def_pack 
VALUES(25,14,'Dendranthema tros santin');
INSERT INTO hol_subtype_def_pack 
VALUES(10,15,'Dendrant. geplozen kas');
INSERT INTO hol_subtype_def_pack 
VALUES(1,1,'sdfsdfsdf');
